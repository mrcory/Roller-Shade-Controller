//Lighting effect functions for addressable LEDs will be here
