  char auth[35] = "2cac3dcbb3794192b74cb09a10ede174";
  char ssid[] = "dd-wrt";
  char pass[] = "";
  char server[] = "blynk.mrcory.net";
  int port = 8080;
