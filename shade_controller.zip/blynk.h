  char auth[35] = "";
  char ssid[] = "dd-wrt";
  char pass[] = "";
  char server[] = "";
  int port = 8080;
