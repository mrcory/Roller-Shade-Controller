  char auth[35] = "";
  char ssid[] = "";
  char pass[] = "";
  char server[] = "";
  int port = 8080;
