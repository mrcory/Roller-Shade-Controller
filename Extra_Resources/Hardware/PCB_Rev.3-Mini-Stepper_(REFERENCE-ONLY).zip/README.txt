As this is an untested board design, I can not be certain that it is viable to have made.
There could be unfound errors in this design. I take no responsibility for any damage or loss caused
by using it.

YOU are taking all risks assaociated with using this board. Any property damage, injury, or death caused 
by the usage of this design in YOUR sole responsibility.

These files are provided for reference only.

These files are only allowed to be used for personal usage. They may not be used to produce any product for
commercial usage or resale.